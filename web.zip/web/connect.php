<?php

$con=mysqli_connect("localhost","root","","tour_database");
	if(!$con)
		die("cannot connect to server");

?>
